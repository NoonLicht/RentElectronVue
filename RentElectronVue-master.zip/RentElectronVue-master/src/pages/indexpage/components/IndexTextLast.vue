<template>
  <div style="position:relative;" class="card-and-globus">

  </div>
</template>

<script>



export default {
  components: {

  }
}
</script>

<style scoped>
@import '@/assets/css/index.css';

.card-and-globus {
  height: 250px;
}
</style>