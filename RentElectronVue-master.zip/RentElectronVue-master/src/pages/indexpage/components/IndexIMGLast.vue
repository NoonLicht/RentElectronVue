<template>
  <div class="bgimg-2">
    <div class="caption">

    </div>
  </div>
</template>


<style>
@import '@/assets/css/index.css';
</style>