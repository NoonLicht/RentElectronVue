<!-- src/pages/blogspage/BlogsPage.vue -->
<template>
  <div>
    <h1>Estate Page</h1>
  </div>
</template>

<script>
export default {
  name: 'BlogsPage'
}
</script>

<style scoped>
/* Ваши стили */
</style>
