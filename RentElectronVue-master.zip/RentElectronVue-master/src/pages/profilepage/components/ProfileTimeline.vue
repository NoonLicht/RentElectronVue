<template>
  <div class="timeline">
    <div class="timeline-left">
      <div class="intro box">
        <div class="intro-title">
          Хотя я?
          <button class="intro-menu"></button>
        </div>
        <div class="info">
          <div class="info-item">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 503.889 503.889" fill="currentColor">
              <path
                d="M453.727 114.266H345.151V70.515c0-20.832-16.948-37.779-37.78-37.779H196.517c-20.832 0-37.78 16.947-37.78 37.779v43.751H50.162C22.502 114.266 0 136.769 0 164.428v256.563c0 27.659 22.502 50.161 50.162 50.161h403.565c27.659 0 50.162-22.502 50.162-50.161V164.428c0-27.659-22.503-50.162-50.162-50.162zm-262.99-43.751a5.786 5.786 0 015.78-5.779h110.854a5.786 5.786 0 015.78 5.779v43.751H190.737zM32 164.428c0-10.015 8.147-18.162 18.162-18.162h403.565c10.014 0 18.162 8.147 18.162 18.162v23.681c0 22.212-14.894 42.061-36.22 48.27l-167.345 48.723a58.482 58.482 0 01-32.76 0L68.22 236.378C46.894 230.169 32 210.321 32 188.109zm421.727 274.725H50.162c-10.014 0-18.162-8.147-18.162-18.161V253.258c8.063 6.232 17.254 10.927 27.274 13.845 184.859 53.822 175.358 52.341 192.67 52.341 17.541 0 7.595 1.544 192.67-52.341 10.021-2.918 19.212-7.613 27.274-13.845v167.733c.001 10.014-8.147 18.162-18.161 18.162z" />
            </svg>
            Бла-бла-бла РМАНПО
          </div>
          <div class="info-item">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-width="2"
              stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
              <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z" />
              <path d="M9 22V12h6v10" />
            </svg>
            Проживаю в Москве
          </div>
          <div class="info-item">
            <svg viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg" fill="currentColor">
              <path
                d="M437 75C388.7 26.6 324.4 0 256 0S123.3 26.6 75 75C26.6 123.3 0 187.6 0 256s26.6 132.7 75 181c48.3 48.4 112.6 75 181 75s132.7-26.6 181-75c48.4-48.3 75-112.6 75-181s-26.6-132.7-75-181zM252.4 481.9c-52-.9-103.7-19.5-145.2-55.8L256 277.2l21.7 21.8a165.9 165.9 0 00-35.7 87c-3.5 30.5 0 63.3 10.4 95.9zM299 320.3l105.7 105.8a224.8 224.8 0 01-121.3 54.1C262 419.5 268 360.3 299 320.3zm21.2-21.2c40-31 99.2-37 160-15.6A224.8 224.8 0 01426 404.8zM482 252.4a231.7 231.7 0 00-96-10.4 165.9 165.9 0 00-87 35.7L277.3 256l148.9-148.8c36.3 41.5 55 93.2 55.8 145.2zm-290.2-39.5c-40 31-99.2 37-160 15.6A224.8 224.8 0 0186 107.2zm-84.5-127a224.8 224.8 0 01121.3-54.1C250 92.5 244 151.7 213 191.7zM270 126c3.5-30.5 0-63.3-10.4-95.9 52 .9 103.7 19.5 145.2 55.8L256 234.8 234.3 213a165.9 165.9 0 0035.7-87zM30 259.6a242 242 0 0072.7 11.7c7.8 0 15.6-.5 23.2-1.3a165.9 165.9 0 0087-35.7l21.8 21.7L85.9 404.8a225.3 225.3 0 01-55.8-145.2z" />
            </svg>
            бубубубубубу
          </div>
        </div>
      </div>
    </div>
    <div class="timeline-right">
      <div class="status box">
        <div class="status-menu">
          <a class="status-menu-item active" href="#">Статус</a>
          <a class="status-menu-item" href="#">Фото</a>
          <a class="status-menu-item" href="#">Видео</a>
        </div>
        <div class="status-main">
          <img
            src="https://wdorogu.ru/images/wp-content/uploads/2020/10/1493123379_myau-krasivye-foto-malenkih-kotov-10.jpg"
            class="status-img">
          <textarea class="status-textarea" placeholder="Что бы сюда написать?"></textarea>
        </div>
        <div class="status-actions">
          <a href="#" class="status-action">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
              <path
                d="M87.084 192c-.456-5.272-.688-10.6-.688-16C86.404 78.8 162.34 0 256.004 0s169.6 78.8 169.6 176c0 5.392-.232 10.728-.688 16h.688c0 96.184-169.6 320-169.6 320s-169.6-223.288-169.6-320h.68zm168.92 32c36.392 1.024 66.744-27.608 67.84-64-1.096-36.392-31.448-65.024-67.84-64-36.392-1.024-66.744 27.608-67.84 64 1.096 36.392 31.448 65.024 67.84 64z"
                fill="#e21b1b" />
            </svg>
            Места
          </a>
          <a href="#" class="status-action">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
              <circle cx="256" cy="256" r="256" fill="#ffca28" />
              <g fill="#6d4c41">
                <path
                  d="M399.68 208.32c-8.832 0-16-7.168-16-16 0-17.632-14.336-32-32-32s-32 14.368-32 32c0 8.832-7.168 16-16 16s-16-7.168-16-16c0-35.296 28.704-64 64-64s64 28.704 64 64c0 8.864-7.168 16-16 16zM207.68 208.32c-8.832 0-16-7.168-16-16 0-17.632-14.368-32-32-32s-32 14.368-32 32c0 8.832-7.168 16-16 16s-16-7.168-16-16c0-35.296 28.704-64 64-64s64 28.704 64 64c0 8.864-7.168 16-16 16z" />
              </g>
              <path
                d="M437.696 294.688c-3.04-4-7.744-6.368-12.736-6.368H86.4c-5.024 0-9.728 2.336-12.736 6.336-3.072 4.032-4.032 9.184-2.688 14.016C94.112 390.88 170.08 448.32 255.648 448.32s161.536-57.44 184.672-139.648c1.376-4.832.416-9.984-2.624-13.984z"
                fill="#fafafa" />
            </svg>
            Настроение
          </a>
          <button class="status-share">Поделиться</button>
        </div>
      </div>
      <div class="album box">
        <div class="status-main">
          <img
            src="https://wdorogu.ru/images/wp-content/uploads/2020/10/1493123379_myau-krasivye-foto-malenkih-kotov-10.jpg"
            class="status-img" />
          <div class="album-detail">
            <div class="album-title"><strong>David Grechka</strong></div>
            <div class="album-date">6 часов назад</div>
          </div>
          <button class="intro-menu"></button>
        </div>
        <div class="album-content">Бла-бла-бла Бла-бла-бла-бла-бла Бла-бла Бла-бла
          <div class="album-photos">
            <img src="https://chudo-prirody.com/uploads/posts/2021-08/1628647490_127-p-udivlennii-kot-foto-133.jpg"
              alt="" class="album-photo" />
            <div class="album-right">
              <img
                src="https://gas-kvas.com/grafic/uploads/posts/2023-09/1695931383_gas-kvas-com-p-kartinki-s-kotami-9.jpg"
                alt="" class="album-photo" />
              <img src="https://w.forfun.com/fetch/d5/d588c79ee2ec4814cc38656eee18004e.jpeg" alt=""
                class="album-photo" />
            </div>
          </div>
        </div>
        <div class="album-actions">
          <a href="#" class="album-action">
            <svg stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"
              viewBox="0 0 24 24">
              <path
                d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z" />
            </svg>
            87
          </a>
          <a href="#" class="album-action">
            <svg stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"
              class="css-i6dzq1" viewBox="0 0 24 24">
              <path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z" />
            </svg>
            20
          </a>
        </div>
      </div>
    </div>
  </div>
</template>

<style >
.timeline {
  display: flex;
  padding-top: 20px;
  position: relative;
  z-index: 2;
}

.timeline-left {
  width: 310px;
  flex-shrink: 0;
  
}

.timeline-right {
  flex-grow: 1;
  padding-left: 20px;
}

@media screen and (max-width: 768px) {
  .timeline {
    flex-wrap: wrap;
    flex-direction: column-reverse;
  }

  .timeline-right {
    padding-left: 0;
    margin-bottom: 20px;
  }

  .timeline-left {
    width: 100%;
  }
}

.box {
  background-color: #ffffff;
  border-radius: 4px;
  box-shadow: 0px 0px 11px 0px rgba(34, 60, 80, 0.2);
}

.intro {
  padding: 20px;
}

.intro-title {
  font-family: "DM Sans", sans-serif;
  color: #5c5e6e;
  font-weight: 600;
  font-size: 18px;
  display: flex;
  align-items: center;
  margin-bottom: 20px;
}

.intro-menu {
  background-color: #8f98a9;
  box-shadow: -8px 0 0 0 #8f98a9, 8px 0 0 0 #8f98a9;
  width: 5px;
  height: 5px;
  border: 0;
  padding: 0;
  border-radius: 50%;
  margin-left: auto;
  margin-right: 8px;
}


.info {
  font-size: 15px;
}

.info-item {
  display: flex;
  color: #000000;
}

.info-item+.info-item {
  margin-top: 14px;
}

.info-item a {
  margin-left: 6px;
  color: #1771d6;
  text-decoration: none;
}

.info-item svg {
  width: 16px;
  margin-right: 10px;
}

.user {
  display: flex;
  align-items: center;
  cursor: pointer;
}

.user+.user {
  margin-top: 18px;
}

.user-img {
  border-radius: 50%;
  width: 45px;
  height: 45px;
  margin-right: 15px;
  object-fit: cover;
  object-position: center;
}

.username {
  font-size: 15px;
  font-family: "DM Sans", sans-serif;
}

.status-menu {
  padding: 20px;
  display: flex;
  align-items: center;
}

.status-menu-item {
  text-decoration: none;
  color: #ccc8db;
  padding: 10px 14px;
  line-height: 0.7;
  font-family: "DM Sans", sans-serif;
  font-weight: 500;
  border-radius: 20px;
}

.status-menu-item.active,
.status-menu-item:hover {
  background-color: #2e2e40;
  color: #fff;
}

.status-menu-item+.status-menu-item {
  margin-left: 10px;
}

@media screen and (max-width: 500px) {
  .status-menu {
    font-size: 14px;
  }

  .status-menu-item+.status-menu-item {
    margin-left: 0;
  }
}

.status-img {
  width: 50px;
  height: 50px;
  object-fit: cover;
  border-radius: 50%;
  margin-right: 20px;
}

.status-main {
  padding: 0 20px;
  display: flex;
  align-items: center;
  border-bottom: 1px solid #272a3a;
  padding-bottom: 20px;
  flex-wrap: wrap;
}

.status-textarea {
  flex-grow: 1;
  background-color: transparent;
  border: none;
  resize: none;
  margin-top: 15px;
  color: #fff;
  max-width: calc(100% - 70px);
}

.status-textarea::placeholder {
  color: #5c5d71;
}

.status-actions {
  display: flex;
  padding: 10px 20px;
}

.status-action {
  text-decoration: none;
  color: #ccc8db;
  margin-right: 20px;
  display: flex;
  align-items: center;
}

.status-action svg {
  width: 16px;
  flex-shrink: 0;
  margin-right: 8px;
}

@media screen and (max-width: 1320px) {
  .status-action {
    width: 16px;
    overflow: hidden;
    color: transparent;
    white-space: nowrap;
  }
}

.status-share {
  background-color: #1b86f9;
  border: none;
  color: #fff;
  border-radius: 4px;
  padding: 10px 20px;
  margin-left: auto;
  box-shadow: 0 0 20px #1b86f9;
  cursor: pointer;
}

.album {
  
  padding-top: 20px;
  margin-top: 20px;
}

.album .status-main {
  border: none;
  display: flex;
}

.album .intro-menu {
  margin-bottom: auto;
  margin-top: 5px;
}

.album-detail {
  display: flex;
  width: calc(100% - 110px);
  font-size: 15px;
  flex-direction: column;
  align-items: flex-start;
}

.album-title span {
  color: #1771d6;
  cursor: pointer;
  font-size: 15px;
}

.album-date {
  font-size: 15px;
  color: #595c6c;
  margin-top: 4px;
}

.album-content {
  display: flex;
  font-size: 20px;
  padding: 0 20px 20px;
  flex-direction: column;
  align-items: flex-start;
}

.album-photo {
  width: 100%;
  object-fit: cover;
  object-position: center;
  border-radius: 4px;
  margin-top: 10px;
}

.album-photos {
  display: flex;
  margin-top: 20px;
  max-height: 30vh;
}

.album-photos>.album-photo {
  width: 50%;
}

.album-right {
  width: 50%;
  margin-left: 10px;
  line-height: 0;
  display: flex;
  flex-direction: column;
}

.album-right .album-photo {
  height: calc(50% - 10px);
}

.album-actions {
  display: flex;
    font-size: 20px;
    padding: 0 20px 20px;
    flex-direction: row;
    align-items: flex-start;
}

.album-action {
  margin-right: 20px;
  text-decoration: none;
  color: #a2a4b4;
  display: inline-flex;
  align-items: center;
  font-weight: 600;
}

.album-action:hover {
  color: #000000;
}

.album-action svg {
  width: 16px;
  margin-right: 6px;
}


</style>